In here are directories that contain the code for the lambda functions.

Within each one, type "npm install" and then zip up the entire folder to load up into AWS lambda function.
