import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  /* config options here */
  // Comment out these things below to run on local server
  // output: 'export',
  // basePath: '/food4u',
};

export default nextConfig;
